// test.js — SPEC.md §14 の例をそのままテストにしたもの。
// engine.js を変更したら `npm test` で壊れていないことを確認する。

const assert = require("assert");
const E = require("./engine.js");

const SAMPLE = `# tasks

- [ ] t-0001 就活 {cat: 就活, pri: high, owner: human}
  - [ ] t-0012 SCREENのESを出す {pri: high, due: 2026-09-20, est: 480}
    - [x] t-0013 募集職種を決める {est: 60, done: 2026-09-05}
    - [ ] t-0014 ESを書く {pri: high, due: 2026-09-15, est: 180, owner: either, deps: [t-0013]}
      - note: 志望動機は研究テーマとの接点を軸にする
    - [ ] t-0015 動画を撮る {est: 120}
    - [ ] t-0016 上司にチェックしてもらう {deps: [t-0014, t-0015]}
  - [ ] t-0002 SPI対策 {pri: mid, due: 2026-09-05, soft: true, est: 480, owner: either}
- [ ] t-0020 修論の中間発表スライド {cat: 研究, pri: high, due: 2026-09-08, est: 480, owner: human}
- [ ] t-0030 生徒の保護者へ月謝の件で返信 {cat: 家庭教師, pri: mid, due: 2026-09-06, est: 15, owner: either}
- [ ] t-0040 授業準備 {cat: 家庭教師, pri: mid, due: 2026-09-09, est: 60, repeat: weekly, owner: human}
`;

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`ok   ${name}`); }
  catch (e) { console.log(`FAIL ${name}\n     ${e.message}`); process.exitCode = 1; }
}

test("§14 の順序", () => {
  const r = E.compute(E.parse(SAMPLE), "2026-09-06");
  assert.deepStrictEqual(r.actionable.map((t) => t.id), ["t-0030", "t-0020", "t-0014", "t-0040", "t-0015", "t-0002"]);
  assert.deepStrictEqual(r.blocked.map((t) => t.id), ["t-0016"]);
  assert.strictEqual(r.next.id, "t-0030");
});

test("猶予: 8時間タスクは締切2日前から緊急 (t-0020)", () => {
  const r = E.compute(E.parse(SAMPLE), "2026-09-06");
  assert.strictEqual(r.byId["t-0020"].isUrgent, true);
  const r2 = E.compute(E.parse(SAMPLE), "2026-09-05");
  assert.strictEqual(r2.byId["t-0020"].isUrgent, false);
});

test("soft 締切は繰り上がらず、期限切れは due 無しより後ろ (t-0002)", () => {
  const r = E.compute(E.parse(SAMPLE), "2026-09-06");
  const t = r.byId["t-0002"];
  assert.strictEqual(t.isUrgent, false);
  assert.strictEqual(t.softExpired, true);
  assert.ok(r.review.some((x) => x.id === "t-0002"));
  const ids = r.actionable.map((x) => x.id);
  assert.ok(ids.indexOf("t-0015") < ids.indexOf("t-0002"));
});

test("カテゴリの継承", () => {
  const r = E.compute(E.parse(SAMPLE), "2026-09-06");
  assert.strictEqual(r.byId["t-0014"].cat, "就活");
  assert.strictEqual(r.byId["t-0020"].cat, "研究");
});

test("コンテナは実行可能に入らず、進捗を持つ", () => {
  const r = E.compute(E.parse(SAMPLE), "2026-09-06");
  assert.ok(!r.actionable.some((t) => t.isContainer));
  assert.deepStrictEqual(r.byId["t-0012"].progress, { done: 1, total: 4 });
});

test("done: 親の自動完了は全ての子が終わったときだけ", () => {
  let p = E.parse(SAMPLE);
  p = E.parse(E.markDone(p, "t-0014", "2026-09-10", "t").lines.join("\n"));
  p = E.parse(E.markDone(p, "t-0015", "2026-09-10", "t").lines.join("\n"));
  assert.strictEqual(p.byId["t-0012"].state, "todo");
  const { lines, logEntries } = E.markDone(p, "t-0016", "2026-09-11", "ai:test");
  p = E.parse(lines.join("\n"));
  assert.strictEqual(p.byId["t-0012"].state, "done");
  assert.strictEqual(p.byId["t-0001"].state, "todo"); // t-0002 が残っている
  assert.strictEqual(logEntries.length, 2);
  assert.deepStrictEqual(p.byId["t-0014"].notes, ["志望動機は研究テーマとの接点を軸にする"]); // note 温存
});

test("done: repeat は完了せず due が進む", () => {
  const { lines } = E.markDone(E.parse(SAMPLE), "t-0040", "2026-09-09", "human");
  const t = E.parse(lines.join("\n")).byId["t-0040"];
  assert.strictEqual(t.state, "todo");
  assert.strictEqual(t.attrs.due, "2026-09-16");
  assert.strictEqual(t.attrs.last, "2026-09-09");
});

test("done: コンテナは直接完了できない", () => {
  assert.throws(() => E.markDone(E.parse(SAMPLE), "t-0001", "2026-09-06", "human"), /コンテナ/);
});

test("advance: monthly の月末丸め", () => {
  assert.strictEqual(E.advance("2026-01-31", "monthly"), "2026-02-28");
  assert.strictEqual(E.advance("2026-12-15", "monthly"), "2027-01-15");
  assert.strictEqual(E.advance("2026-09-06", "2w"), "2026-09-20");
  assert.strictEqual(E.advance("2028-02-29", "yearly"), "2029-02-28");
});

test("削除済みの deps はブロックしない", () => {
  const r = E.compute(E.parse("- [ ] t-0001 a {deps: [t-9999]}\n"), "2026-09-06");
  assert.strictEqual(r.byId["t-0001"].isBlocked, false);
});

test("nextId", () => {
  assert.strictEqual(E.nextId(E.parse(SAMPLE)), "t-0041");
});

console.log(`\n${passed} passed`);
