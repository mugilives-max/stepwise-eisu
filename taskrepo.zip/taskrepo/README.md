# tasks

人間(ユウスケ)と複数のAIが共有するタスクの作業記憶。特定のAIに依存しない。

**AIへ: このリポジトリを扱うときは、最初に [SPEC.md](SPEC.md) を読むこと。** そこに書式と、AIが何をしてよくて何をしてはいけないかが全て書いてある。

## ファイル

| | |
|---|---|
| `SPEC.md` | 書式と全ルール。唯一の正 |
| `tasks.md` | タスク本体 |
| `knowledge.md` | 背景知識。会話のたびに説明しなくて済むようにするためのもの |
| `log.md` | 変更の記録。追記のみ |
| `engine.js` | 順序付けの実装。Node とブラウザ共用 |
| `next.js` | CLI |
| `viewer.html` | 人間用の画面 |
| `test.js` | SPEC §14 をテストにしたもの |

## 使い方(人間)

```
node next.js                       # 次にやることと、順序付きの一覧
node next.js done t-0012 --actor human
```

画面で見たいときは、リポジトリのディレクトリで簡易サーバーを立てて `viewer.html` を開く。

```
npx serve .          # または  python3 -m http.server 8000
```

スマホからは、GitHub Pages で公開するか(非公開リポジトリでは GitHub Pro が必要)、ブラウザで `viewer.html` を直接開いて `tasks.md` を選ぶ。

## 使い方(AI)

1. `git pull`
2. `SPEC.md` → `knowledge.md` → `tasks.md` の順に読む
3. `node next.js` で現状を把握する
4. 変更するなら `tasks.md` を編集し、`log.md` に追記する。完了は `node next.js done <id> --actor ai:<名前>` を使う
5. 意味のある単位で `git commit` して `git push`

Claude Code、ChatGPT(Codex / GitHub 連携)、Cowork など、リポジトリを読み書きできるものなら何でも同じ手順で動く。

## セットアップ

```
git init
git add .
git commit -m "init"
# GitHub に非公開リポジトリを作ってから
git remote add origin git@github.com:<you>/tasks.git
git push -u origin main
```

`npm test` で SPEC の例が通ることを確認できる。engine.js を変更したら必ず走らせる。
