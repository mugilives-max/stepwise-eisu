# tasks

- [ ] t-0001 就活 {cat: 就活, pri: high, owner: human}
  - [ ] t-0012 SCREENのESを出す {pri: high, due: 2026-09-20, est: 480}
    - [x] t-0013 募集職種を決める {est: 60, done: 2026-09-05}
    - [ ] t-0014 ESを書く {pri: high, due: 2026-09-15, est: 180, owner: either, deps: [t-0013]}
      - note: 志望動機は研究テーマとの接点を軸にする
    - [ ] t-0015 動画を撮る {est: 120}
    - [ ] t-0016 上司にチェックしてもらう {deps: [t-0014, t-0015]}
  - [ ] t-0002 SPI対策 {pri: mid, due: 2026-09-05, soft: true, est: 480, owner: either}
- [ ] t-0020 修論の中間発表スライド {cat: 研究, pri: high, due: 2026-09-08, est: 480, owner: human}
- [ ] t-0030 生徒の保護者へ月謝の件で返信 {cat: 家庭教師, pri: mid, due: 2026-09-06, est: 15, owner: either}
- [ ] t-0040 授業準備 {cat: 家庭教師, pri: mid, due: 2026-09-09, est: 60, repeat: weekly, owner: human}
