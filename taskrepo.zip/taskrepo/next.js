#!/usr/bin/env node
// next.js — CLI。SPEC.md §12 で AI/人間が使う入口。
//
//   node next.js                    次にやることと、順序付きの一覧を表示
//   node next.js --json             同じ内容を JSON で
//   node next.js --today 2026-09-06 日付を固定して評価(テスト用)
//   node next.js done t-0012 --actor ai:claude
//                                   完了処理。親の自動完了・repeat の繰り越しを行い、log.md に追記
//   node next.js id                 次に使う id を表示

const fs = require("fs");
const path = require("path");
const E = require("./engine.js");

const ROOT = __dirname;
const TASKS = path.join(ROOT, "tasks.md");
const LOG = path.join(ROOT, "log.md");

const argv = process.argv.slice(2);
const flag = (name) => {
  const i = argv.indexOf(name);
  return i === -1 ? null : argv[i + 1];
};
const has = (name) => argv.includes(name);
const positional = argv.filter((a, i) => !a.startsWith("--") && !(i > 0 && argv[i - 1].startsWith("--")));

const today = flag("--today") || E.todayLocal();
const text = fs.readFileSync(TASKS, "utf8");
const parsed = E.parse(text);

const cmd = positional[0] || "next";

if (cmd === "id") {
  console.log(E.nextId(parsed));
  process.exit(0);
}

if (cmd === "done") {
  const id = positional[1];
  if (!id) {
    console.error("usage: node next.js done t-XXXX --actor ai:name|human");
    process.exit(1);
  }
  const actor = flag("--actor");
  if (!actor) console.error("warning: --actor が指定されていません。log には unknown と記録します");
  let result;
  try {
    result = E.markDone(parsed, id, today, actor || "unknown");
  } catch (e) {
    console.error(`error: ${e.message}`);
    process.exit(1);
  }
  const { lines, logEntries } = result;
  fs.writeFileSync(TASKS, lines.join("\n"));
  fs.appendFileSync(LOG, (fs.existsSync(LOG) && !fs.readFileSync(LOG, "utf8").endsWith("\n") ? "\n" : "") + logEntries.join("\n") + "\n");
  logEntries.forEach((l) => console.log(l));
  process.exit(0);
}

// ---- next (default) ----------------------------------------------------------

const r = E.compute(parsed, today);

if (has("--json")) {
  const slim = (t) => ({
    id: t.id, title: t.title, cat: t.cat, pri: t.pri, due: t.due, soft: t.soft, est: t.est,
    owner: t.owner, repeat: t.repeat, parent: t.parent, urgent: t.isUrgent, slack: t.slack,
    blocked: t.isBlocked, waitingOn: t.waitingOn, softExpired: t.softExpired, notes: t.notes,
  });
  console.log(JSON.stringify({
    today: r.today,
    next: r.next ? slim(r.next) : null,
    actionable: r.actionable.map(slim),
    blocked: r.blocked.map(slim),
    review: r.review.map((t) => ({ id: t.id, title: t.title, reason: t.softExpired ? "soft締切切れ" : "全ての子が完了(自動完了待ち)" })),
    containers: r.containers.map((t) => ({ id: t.id, title: t.title, parent: t.parent, progress: t.progress })),
  }, null, 2));
  process.exit(0);
}

console.log(`# ${r.today}`);
console.log("");
if (r.next) console.log(`次にやること: ${r.next.id} ${r.next.title}  [${r.next.cat}]  ${E.describe(r.next)}`);
else console.log("次にやること: なし(実行可能なタスクがありません)");
console.log("");

console.log("## 実行可能(順)");
r.actionable.forEach((t, i) => console.log(`${String(i + 1).padStart(2)}. ${t.id} ${t.title}  [${t.cat}]  ${E.describe(t)}`));
if (!r.actionable.length) console.log("(なし)");
console.log("");

if (r.blocked.length) {
  console.log("## ブロック中(前提待ち)");
  r.blocked.forEach((t) => console.log(`  - ${t.id} ${t.title}  ← 待ち: ${t.waitingOn.join(", ")}`));
  console.log("");
}

if (r.review.length) {
  console.log("## 見直し");
  r.review.forEach((t) => {
    if (t.softExpired) console.log(`  - ${t.id} ${t.title}: soft 締切 ${t.due} を過ぎています。延ばす / 外す / やめる のどれかを決めてください`);
    if (t.readyToClose) console.log(`  - ${t.id} ${t.title}: 全ての子が完了しています。node next.js done で閉じられていない場合は手で [x] にしてください`);
  });
  console.log("");
}

if (r.containers.length) {
  console.log("## コンテナ(進捗)");
  const printTree = (t, depth) => {
    console.log(`${"  ".repeat(depth)}- ${t.id} ${t.title}  (${t.progress.done}/${t.progress.total})`);
    t.children.map((id) => r.byId[id]).filter((c) => c.isContainer && !c.isDone).forEach((c) => printTree(c, depth + 1));
  };
  r.containers.filter((t) => !t.parent || !r.byId[t.parent].isContainer).forEach((t) => printTree(t, 0));
}
