// engine.js — tasks.md のパーサと順序付け。SPEC.md §3〜§5, §8.5 の実装。
// Node からも ブラウザからも同じファイルを読む。ロジックはここ以外に置かない。

(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.TaskEngine = factory();
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const HOURS_PER_DAY = 4; // 猶予日数の換算 (SPEC §4)。運用しながら調整してよい
  const PRI_RANK = { high: 0, mid: 1, low: 2 };

  // ---- 日付 ---------------------------------------------------------------

  function toDays(ymd) {
    const [y, m, d] = ymd.split("-").map(Number);
    return Math.round(Date.UTC(y, m - 1, d) / 86400000);
  }
  function fromDays(days) {
    const dt = new Date(days * 86400000);
    return dt.toISOString().slice(0, 10);
  }
  function todayLocal() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }
  function isYmd(s) {
    return typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s);
  }

  // repeat を1周期進める (SPEC §8.5)
  function advance(ymd, repeat) {
    const [y, m, d] = ymd.split("-").map(Number);
    const mNum = /^(\d+)([dw])$/.exec(repeat);
    if (mNum) {
      const n = Number(mNum[1]) * (mNum[2] === "w" ? 7 : 1);
      return fromDays(toDays(ymd) + n);
    }
    if (repeat === "daily") return fromDays(toDays(ymd) + 1);
    if (repeat === "weekly") return fromDays(toDays(ymd) + 7);
    if (repeat === "monthly" || repeat === "yearly") {
      const targetM = repeat === "monthly" ? m + 1 : m + 12; // 1-based
      const ty = y + Math.floor((targetM - 1) / 12);
      const tm = ((targetM - 1) % 12) + 1;
      const lastDay = new Date(Date.UTC(ty, tm, 0)).getUTCDate();
      return `${ty}-${String(tm).padStart(2, "0")}-${String(Math.min(d, lastDay)).padStart(2, "0")}`;
    }
    throw new Error(`unknown repeat: ${repeat}`);
  }

  // ---- 属性 ---------------------------------------------------------------

  function parseAttrs(src) {
    const out = {};
    const order = [];
    if (!src) return { attrs: out, order };
    const parts = [];
    let depth = 0, cur = "";
    for (const ch of src) {
      if (ch === "[") depth++;
      if (ch === "]") depth--;
      if (ch === "," && depth === 0) { parts.push(cur); cur = ""; } else cur += ch;
    }
    if (cur.trim()) parts.push(cur);
    for (const part of parts) {
      const i = part.indexOf(":");
      if (i === -1) continue;
      const k = part.slice(0, i).trim();
      let v = part.slice(i + 1).trim();
      if (v.startsWith("[")) v = v.slice(1, -1).split(",").map((x) => x.trim()).filter(Boolean);
      else if (v === "true") v = true;
      else if (v === "false") v = false;
      else if (/^\d+$/.test(v)) v = Number(v);
      out[k] = v;
      order.push(k);
    }
    return { attrs: out, order };
  }

  function formatAttrs(attrs, order) {
    const keys = [...order.filter((k) => k in attrs), ...Object.keys(attrs).filter((k) => !order.includes(k))];
    const parts = keys.map((k) => {
      const v = attrs[k];
      const s = Array.isArray(v) ? `[${v.join(", ")}]` : String(v);
      return `${k}: ${s}`;
    });
    return parts.length ? ` {${parts.join(", ")}}` : "";
  }

  // ---- パース (SPEC §3) --------------------------------------------------------

  const TASK_RE = /^(\s*)- \[( |>|x)\] (t-\d{4}) (.*?)(?:\s*\{(.*)\})?\s*$/;
  const NOTE_RE = /^(\s*)- note:\s?(.*)$/;

  function parse(text) {
    const lines = text.split(/\r?\n/);
    const tasks = [];
    const stack = []; // [{indent, task}]
    lines.forEach((line, idx) => {
      const m = TASK_RE.exec(line);
      if (m) {
        const indent = m[1].length;
        const { attrs, order } = parseAttrs(m[5]);
        while (stack.length && stack[stack.length - 1].indent >= indent) stack.pop();
        const parent = stack.length ? stack[stack.length - 1].task : null;
        const task = {
          id: m[3],
          title: m[4].trim(),
          state: m[2] === "x" ? "done" : m[2] === ">" ? "doing" : "todo",
          attrs,
          attrOrder: order,
          parent: parent ? parent.id : null,
          children: [],
          notes: [],
          line: idx,
          indent,
        };
        if (parent) parent.children.push(task.id);
        tasks.push(task);
        stack.push({ indent, task });
        return;
      }
      const n = NOTE_RE.exec(line);
      if (n && stack.length) stack[stack.length - 1].task.notes.push(n[2]);
    });
    // カテゴリの継承 (SPEC §7)
    const byId = Object.fromEntries(tasks.map((t) => [t.id, t]));
    for (const t of tasks) {
      let cur = t;
      while (cur && !cur.attrs.cat && cur.parent) cur = byId[cur.parent];
      t.cat = (cur && cur.attrs.cat) || "未分類";
    }
    return { tasks, byId, lines };
  }

  // ---- 導出状態と順序 (SPEC §4, §5) ------------------------------------------

  function compute(parsed, today) {
    today = today || todayLocal();
    const T = toDays(today);
    const { tasks, byId } = parsed;

    for (const t of tasks) {
      const a = t.attrs;
      t.isContainer = t.children.length > 0;
      t.isDone = t.state === "done";
      t.owner = a.owner || "human";
      t.pri = PRI_RANK[a.pri] !== undefined ? a.pri : "mid";
      t.est = typeof a.est === "number" ? a.est : null;
      t.due = isYmd(a.due) ? a.due : null;
      t.soft = a.soft === true;
      t.repeat = a.repeat || null;
      t.leadDays = t.est ? Math.ceil(t.est / (HOURS_PER_DAY * 60)) : 0;
      t.daysLeft = t.due ? toDays(t.due) - T : null;
      t.slack = t.due ? t.daysLeft - t.leadDays : null;

      t.isUrgent = !!(t.due && !t.soft && T >= toDays(t.due) - t.leadDays);
      t.softExpired = !!(t.due && t.soft && toDays(t.due) < T);
    }
    // isBlocked は依存先の isDone を見るので、全タスクの isDone が決まってから
    for (const t of tasks) {
      const deps = Array.isArray(t.attrs.deps) ? t.attrs.deps : [];
      t.waitingOn = deps.filter((id) => byId[id] && !byId[id].isDone);
      t.isBlocked = t.waitingOn.length > 0;
      t.isActionable = !t.isContainer && !t.isDone && !t.isBlocked;
    }

    // コンテナの進捗 (SPEC §7)
    for (const t of tasks) {
      if (!t.isContainer) continue;
      const kids = t.children.map((id) => byId[id]);
      t.progress = { done: kids.filter((k) => k.isDone).length, total: kids.length };
      t.readyToClose = !t.isDone && kids.every((k) => k.isDone);
    }

    // rule 4 の due 順位: 有効な due → 0、無し → 1、期限切れ soft → 2
    const dueRank = (t) => (t.softExpired ? 2 : t.due ? 0 : 1);

    const cmp = (a, b) => {
      if (a.isUrgent !== b.isUrgent) return a.isUrgent ? -1 : 1;            // rule 2
      if (a.isUrgent && b.isUrgent) {
        if (a.slack !== b.slack) return a.slack - b.slack;
        return a.daysLeft - b.daysLeft;
      }
      if (PRI_RANK[a.pri] !== PRI_RANK[b.pri]) return PRI_RANK[a.pri] - PRI_RANK[b.pri]; // rule 3
      const ra = dueRank(a), rb = dueRank(b);                                 // rule 4
      if (ra !== rb) return ra - rb;
      if (ra === 0 && a.daysLeft !== b.daysLeft) return a.daysLeft - b.daysLeft;
      return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
    };

    const actionable = tasks.filter((t) => t.isActionable).sort(cmp);         // rule 1 で blocked は別枠
    const blocked = tasks.filter((t) => !t.isContainer && !t.isDone && t.isBlocked).sort(cmp);
    const review = tasks.filter((t) => !t.isDone && (t.softExpired || t.readyToClose));
    const containers = tasks.filter((t) => t.isContainer && !t.isDone);

    return { today, next: actionable[0] || null, actionable, blocked, review, containers, tasks, byId };
  }

  // ---- 完了処理 (SPEC §7 自動完了, §8.5 repeat) ---------------------------------
  // 行単位で書き換え、note などは温存する。戻り値: { lines, logEntries }

  function markDone(parsed, id, today, actor) {
    today = today || todayLocal();
    actor = actor || "unknown";
    const { byId, lines } = parsed;
    const t = byId[id];
    if (!t) throw new Error(`not found: ${id}`);
    if (t.children.length) throw new Error(`${id} はコンテナです。子タスクを完了させると自動で閉じます`);
    const out = lines.slice();
    const log = [];

    const rewrite = (task, state, attrPatch) => {
      const attrs = { ...task.attrs, ...attrPatch };
      for (const k of Object.keys(attrPatch)) if (attrPatch[k] === undefined) delete attrs[k];
      const mark = state === "done" ? "x" : state === "doing" ? ">" : " ";
      out[task.line] = `${" ".repeat(task.indent)}- [${mark}] ${task.id} ${task.title}${formatAttrs(attrs, task.attrOrder)}`;
      task.attrs = attrs;
      task.state = state;
    };

    if (t.attrs.repeat) {
      const base = isYmd(t.attrs.due) ? t.attrs.due : today;
      rewrite(t, "todo", { last: today, due: advance(base, t.attrs.repeat), done: undefined });
      log.push(`- ${today} ${actor} done ${t.id} ${t.title} (repeat → next ${t.attrs.due})`);
      return { lines: out, logEntries: log };
    }

    rewrite(t, "done", { done: today });
    log.push(`- ${today} ${actor} done ${t.id} ${t.title}`);

    // 親の自動完了 (上へ再帰)
    let cur = t.parent ? byId[t.parent] : null;
    while (cur) {
      const allDone = cur.children.every((cid) => byId[cid].state === "done");
      if (!allDone || cur.state === "done") break;
      rewrite(cur, "done", { done: today });
      log.push(`- ${today} ${actor} done ${cur.id} ${cur.title} (auto: all children done)`);
      cur = cur.parent ? byId[cur.parent] : null;
    }
    return { lines: out, logEntries: log };
  }

  function nextId(parsed) {
    const max = parsed.tasks.reduce((m, t) => Math.max(m, Number(t.id.slice(2))), 0);
    return `t-${String(max + 1).padStart(4, "0")}`;
  }

  // ---- 表示用 ------------------------------------------------------------------

  function describe(t) {
    const bits = [];
    if (t.isUrgent) bits.push("緊急");
    if (t.softExpired) bits.push("soft期限切れ");
    bits.push(`pri:${t.pri}`);
    if (t.due) bits.push(`due:${t.due}${t.soft ? "(soft)" : ""}${t.daysLeft < 0 ? ` ${-t.daysLeft}日超過` : t.daysLeft === 0 ? " 今日" : ` あと${t.daysLeft}日`}`);
    if (t.est) bits.push(`est:${t.est}分`);
    if (t.owner !== "human") bits.push(`owner:${t.owner}`);
    if (t.repeat) bits.push(`repeat:${t.repeat}`);
    return bits.join(" ");
  }

  return { parse, compute, markDone, nextId, advance, describe, todayLocal, HOURS_PER_DAY, formatAttrs };
});
